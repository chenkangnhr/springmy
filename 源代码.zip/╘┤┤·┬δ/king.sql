/*
 Navicat MySQL Data Transfer

 Source Server         : 192.168.3.18
 Source Server Type    : MySQL
 Source Server Version : 80018
 Source Host           : 192.168.3.18:3307
 Source Schema         : com

 Target Server Type    : MySQL
 Target Server Version : 80018
 File Encoding         : 65001

 Date: 27/03/2020 08:22:49
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for task_details
-- ----------------------------
DROP TABLE IF EXISTS `task_details`;
CREATE TABLE `task_details`  (
  `task_no` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '任务编号',
  `task_desc` varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '任务描述',
  `task_owner` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '任务所有者',
  `task_type` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '任务类型，ELog,Esearch,Project,Training',
  `task_stat` varchar(3) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '任务状态,1:计划中，2：Ur阶段，3：coding；4：sit；5：UAT；6：Done；9：进行中',
  `sit_date` datetime(0) NULL DEFAULT NULL COMMENT '集成测试日期',
  `uat_date` datetime(0) NULL DEFAULT NULL COMMENT '用户测试日期',
  `release_date` datetime(0) NULL DEFAULT NULL COMMENT '发布日期',
  `plan_man_days` bigint(13) NOT NULL COMMENT '计划工时',
  `actual_days` bigint(13) NOT NULL COMMENT '实际工时',
  `task_month` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '任务处理年月',
  `create_day` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modify_day` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`task_no`, `task_owner`, `task_type`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '公司员工任务明细' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of task_details
-- ----------------------------
INSERT INTO `task_details` VALUES ('20193624', '高净值需求', '383604', 'ELOG', '1', '2020-03-24 20:03:55', '2020-03-28 20:04:00', '2020-04-01 20:04:07', 8, 0, '202003', '2020-03-22 20:04:43', '2020-03-22 20:04:38');
INSERT INTO `task_details` VALUES ('20200120', '新产品开发需求', '3836005', 'Project', '1', '2020-04-01 20:09:21', '2020-04-23 20:09:28', '2020-05-01 20:09:35', 200, 0, '202003', '2020-03-22 20:10:00', '2020-03-22 20:09:56');

-- ----------------------------
-- Table structure for temployee_details
-- ----------------------------
DROP TABLE IF EXISTS `temployee_details`;
CREATE TABLE `temployee_details`  (
  `emp_no` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '员工编号',
  `manger_no` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'Leader编号',
  `emp_eng_nm` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '员工英文名称',
  `emp_chn_nm` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '员工中文名称',
  `group` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '任务模块',
  `nation_code` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '国籍',
  `id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '员工证件编码',
  `id_type` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '证件类型',
  `sex_code` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '性别',
  `birthday` datetime(0) NULL DEFAULT NULL COMMENT '出生日期',
  `moble_phone` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机号',
  `address` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '联系地址',
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '邮箱',
  `join_day` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '入职时间',
  `expire_day` datetime(0) NULL DEFAULT NULL COMMENT '离职时间',
  `create_day` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modify_day` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `dept_no` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '部门编号',
  PRIMARY KEY (`emp_no`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of temployee_details
-- ----------------------------
INSERT INTO `temployee_details` VALUES ('383604', '', 'KingLu', '陆游', 'NB', 'CHN', '510106190001010635', '1', 'M', '1990-01-01 22:24:25', '13601799849', '天府三街', 'luyou199011@163.com', '2020-01-04 22:25:06', NULL, '2020-01-04 22:25:06', NULL, '1002');
INSERT INTO `temployee_details` VALUES ('383605', '383604', 'LilyTang', '唐婉', 'NB', 'CHN', '510106190001012243', '1', 'F', '1990-01-01 22:24:25', '13601799840', '天府三街', 'tangwan199011@163.com', '2020-01-04 22:25:06', NULL, '2020-01-04 22:25:06', NULL, '1002');

-- ----------------------------
-- Table structure for temployee_leaves
-- ----------------------------
DROP TABLE IF EXISTS `temployee_leaves`;
CREATE TABLE `temployee_leaves`  (
  `emp_no` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '员工编号',
  `plan_leave_days` bigint(20) NULL DEFAULT NULL COMMENT '计划休假天数',
  `act_leave_days` bigint(20) NULL DEFAULT NULL COMMENT '实际休假天数',
  `leave_year_month` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '休假年月',
  PRIMARY KEY (`emp_no`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of temployee_leaves
-- ----------------------------
INSERT INTO `temployee_leaves` VALUES ('383604', 2, 1, '202003');

-- ----------------------------
-- Table structure for ums_admin
-- ----------------------------
DROP TABLE IF EXISTS `ums_admin`;
CREATE TABLE `ums_admin`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `nick_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `note` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `login_time` datetime(0) NULL DEFAULT NULL,
  `status` int(2) NULL DEFAULT 1,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ums_admin
-- ----------------------------
INSERT INTO `ums_admin` VALUES (1, 'admin', '$2a$10$L6Oclq7AvzwJKXEVLjCGVuRUJCghx3rYDjEbuGT5n8QYOcB3KNYBC', 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif', 'chenkang198933@163.com', 'KingChen', '超级管理员', '2020-03-15 00:28:55', '2020-03-15 00:28:58', 1);

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `empno` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `nick_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `note` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `login_time` datetime(0) NULL DEFAULT NULL,
  `status` int(2) NULL DEFAULT 1,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'luyou199011@163.com', '$2a$10$L6Oclq7AvzwJKXEVLjCGVuRUJCghx3rYDjEbuGT5n8QYOcB3KNYBC', 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif', '383604', 'KingLu', '超级管理员', '2020-03-15 00:28:55', '2020-03-15 00:28:58', 1);
INSERT INTO `users` VALUES (2, 'tangwan199011@163.com', '$2a$10$gkh20pzDg/unwPGLV/Wakum1hpFxILYjh8y9ucjsTOQzGtVw0j5..', 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif', '383605', 'Ruru', '系统管理员', '2020-03-20 22:45:18', '2020-03-20 22:45:27', 1);

SET FOREIGN_KEY_CHECKS = 1;
