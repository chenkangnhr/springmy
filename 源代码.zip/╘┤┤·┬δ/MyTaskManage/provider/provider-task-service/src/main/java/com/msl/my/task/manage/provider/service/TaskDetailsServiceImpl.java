package com.msl.my.task.manage.provider.service;

import com.msl.my.task.manage.provider.api.TaskDetailsService;
import com.msl.my.task.manage.provider.domain.TaskDetails;
import com.msl.my.task.manage.provider.mapper.TaskDetailsMapper;
import org.apache.dubbo.config.annotation.Service;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;

/**
 * @author chenk
 */
@Service(version = "1.0.0")
public class TaskDetailsServiceImpl implements TaskDetailsService {

    @Resource
    private TaskDetailsMapper taskDetailsMapper;

    @Override
    public int insert(TaskDetails taskDetails) {
        return taskDetailsMapper.insert(taskDetails);
    }

    @Override
    public TaskDetails get(String taskOwner) {
        Example example = new Example(TaskDetails.class);
        example.createCriteria().andEqualTo("taskOwner", taskOwner);
        return taskDetailsMapper.selectOneByExample(example);
    }

    @Override
    public int update(TaskDetails taskDetails) {
        return taskDetailsMapper.updateByPrimaryKey(taskDetails);
    }
}
