package com.msl.my.task.manage.provider.mapper;

import com.msl.my.task.manage.provider.domain.TaskDetails;
import tk.mybatis.mapper.MyMapper;

/**
 * @author chenk
 */
public interface TaskDetailsMapper extends MyMapper<TaskDetails> {
}