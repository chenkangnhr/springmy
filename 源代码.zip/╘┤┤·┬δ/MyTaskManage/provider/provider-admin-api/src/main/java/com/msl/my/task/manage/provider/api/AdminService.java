package com.msl.my.task.manage.provider.api;

import com.msl.my.task.manage.provider.domain.AdminUser;

/**
 * @author chenk
 * <p>
 *     用户管理服务接口
 *     内部暴露的接口，供对内RPC调用
 * </p>
 *
 */
public interface AdminService {
    /**
     * 新增用户
     *
     * @param adminUser {@link com.msl.my.task.manage.provider.domain.AdminUser}
     * @return {@code int} 大于 0 则表示添加成功
     */
    int insert(AdminUser adminUser);

    /**
     * 获取用户
     *
     * @param email 用户名
     * @return {@link AdminUser}
     */
    AdminUser get(String email);

    /**
     * 获取用户
     *
     * @param adminUser {@link AdminUser}
     * @return {@link AdminUser}
     */
    AdminUser get(AdminUser adminUser);

    /**
     * 更新用户
     * <p>
     * 仅允许更新 邮箱、昵称、备注、状态
     * </p>
     *
     * @param adminUser {@link AdminUser}
     * @return {@code int} 大于 0 则表示更新成功
     */
    int update(AdminUser adminUser);

    /**
     * 修改密码
     *
     * @param email {@code String} 用户名
     * @param password {@code String} 明文密码
     * @return {@code int} 大于 0 则表示更新成功
     */
    int modifyPassword(String email, String password);

    /**
     * 修改头像
     *
     * @param email {@code String} 用户名
     * @param path     {@code String} 头像地址
     * @return {@code int} 大于 0 则表示更新成功
     */
    int modifyIcon(String email, String path);
}
