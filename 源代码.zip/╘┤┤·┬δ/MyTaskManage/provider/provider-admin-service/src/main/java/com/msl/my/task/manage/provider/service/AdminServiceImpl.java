package com.msl.my.task.manage.provider.service;

import com.msl.my.task.manage.provider.api.AdminService;
import com.msl.my.task.manage.provider.domain.AdminUser;
import com.msl.my.task.manage.provider.mapper.AdminUserMapper;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.util.Date;

/**
 * @author chenk
 */
@Service(version = "1.0.0")
public class AdminServiceImpl implements AdminService {
    @Resource
    private AdminUserMapper adminUserMapper;

    @Resource
    private BCryptPasswordEncoder passwordEncoder;

    @Override
    public int insert(AdminUser adminUser) {
        // 初始化用户对象
        initUmsAdmin(adminUser);
        return adminUserMapper.insert(adminUser);
    }

    /**
     * 熔断器的使用
     *
     * <p>
     * * </p>
     *
     * @param email {@code String} 用户名
     * @return {@link AdminUser}
     */
    @Override
    public AdminUser get(String email) {
        Example example = new Example(AdminUser.class);
        example.createCriteria().andEqualTo("email", email);
        return adminUserMapper.selectOneByExample(example);
    }

    @Override
    public AdminUser get(AdminUser adminUser) {
        return adminUserMapper.selectOne(adminUser);
    }

    @Override
    public int update(AdminUser adminUser) {
        // 获取原始用户信息
        AdminUser oldAdmin = get(adminUser.getEmail());

        // 仅更新 邮箱、昵称、备注、状态
        oldAdmin.setEmpNo(adminUser.getEmpNo());
        oldAdmin.setNickName(adminUser.getNickName());
        oldAdmin.setNote(adminUser.getNote());
        oldAdmin.setStatus(adminUser.getStatus());

        return adminUserMapper.updateByPrimaryKey(oldAdmin);
    }

    @Override
    public int modifyPassword(String email, String password) {
        AdminUser adminUser = get(email);
        adminUser.setPassword(passwordEncoder.encode(password));
        return adminUserMapper.updateByPrimaryKey(adminUser);
    }

    @Override
    public int modifyIcon(String email, String path) {
        AdminUser adminUser = get(email);
        adminUser.setIcon(path);
        return adminUserMapper.updateByPrimaryKey(adminUser);
    }

    /**
     * 初始化用户对象
     *
     * @param adminUser {@link AdminUser}
     */
    private void initUmsAdmin(AdminUser adminUser) {
        // 初始化创建时间
        adminUser.setCreateTime(new Date());
        adminUser.setLoginTime(new Date());

        // 初始化状态
        if (adminUser.getStatus() == null) {
            adminUser.setStatus(0);
        }

        // 密码加密
        adminUser.setPassword(passwordEncoder.encode(adminUser.getPassword()));
    }
}
