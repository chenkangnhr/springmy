package com.msl.my.task.manage.provider.mapper;

import com.msl.my.task.manage.provider.domain.AdminUser;
import tk.mybatis.mapper.MyMapper;

/**
 * @author chenk
 */
public interface AdminUserMapper extends MyMapper<AdminUser> {
}
