package com.msl.my.task.manage.provider;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import tk.mybatis.spring.annotation.MapperScan;

/**
 * @author chenk
 * <p>
 *     DAO 层数据访问层
 * </p>
 */
@SpringBootApplication
@MapperScan(basePackages = "com.msl.my.task.manage.provider.mapper")
public class ProviderAdminApplication {
    public static void main(String[] args) {
        SpringApplication.run(ProviderAdminApplication.class, args);
    }
}
