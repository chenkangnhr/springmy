package com.msl.my.task.manage.provider.service;

import com.msl.my.task.manage.provider.api.AdminService;
import com.msl.my.task.manage.provider.domain.AdminUser;
import com.msl.my.task.manage.provider.mapper.AdminUserMapper;
import org.apache.dubbo.config.annotation.Reference;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AdminServiceImplTest {

    @Resource
    private AdminUserMapper adminUserMapper;

    @Resource
    private AdminService adminService;


    @Test
    public void get() {
        System.out.println(adminService.get("admin"));
    }
}