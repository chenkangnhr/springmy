package com.msl.my.task.manage.provider.api;

import com.msl.my.task.manage.provider.domain.TaskDetails;

/**
 * @author chenk
 * <p>
 *     任务管理服务接口
 *     内部暴露的接口，供对内RPC调用
 * </p>
 *
 */

public interface TaskDetailsService {
    /**
     * 新增任务
     *
     * @param taskDetails {@link com.msl.my.task.manage.provider.domain.TaskDetails}
     * @return {@code int} 大于 0 则表示添加成功
     */
    int insert(TaskDetails taskDetails);

    /**
     * 获取任务信息
     *
     * @param taskOwner 工号
     * @return {@link TaskDetails}
     */
    TaskDetails get(String taskOwner);

    /**
     * 更新任务
     * <p>
     * 仅允许更新 sit时间、UAT时间、上线时间
     * </p>
     *
     * @param taskDetails {@link TaskDetails}
     * @return {@code int} 大于 0 则表示更新成功
     */
    int update(TaskDetails taskDetails);
}
