package com.msl.my.task.manage.business.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 登录信息
 * <p>
 * Description:
 * </p>
 *
 * @author King Chen
 *
 */
@Data
public class LoginInfo implements Serializable {
    private static final long serialVersionUID = -6415696522199534256L;
    private String email;
    private String avatar;
    private String nickName;
}
