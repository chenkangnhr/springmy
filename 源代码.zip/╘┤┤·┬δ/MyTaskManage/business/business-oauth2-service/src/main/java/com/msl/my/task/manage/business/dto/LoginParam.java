package com.msl.my.task.manage.business.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 登录参数
 * <p>
 * Description:
 * </p>
 *
 * @author King Chen
 */
@Data
public class LoginParam implements Serializable {

    private static final long serialVersionUID = -5148145543181103849L;
    private String email;
    private String password;

}
