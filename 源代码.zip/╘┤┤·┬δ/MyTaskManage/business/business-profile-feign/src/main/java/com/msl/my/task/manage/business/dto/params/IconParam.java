package com.msl.my.task.manage.business.dto.params;

import lombok.Data;

import java.io.Serializable;

/**
 * 修改头像参数
 * <p>
 * Description:
 * </p>
 *
 * @author King Chen
 */
@Data
public class IconParam implements Serializable {

    /**
     * 邮箱
     */
    private String email;

    /**
     * 头像地址
     */
    private String path;

}
