package com.msl.my.task.manage.business.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 管理员信息
 * <p>
 * Description:
 * </p>
 *
 * @author King Chen
 */
@Data
public class AdminUserDTO implements Serializable {
    private static final long serialVersionUID = 6033459666897527185L;
    private Long id;
    /**
     * 邮箱
     */
    private String email;

    /**
     * 头像
     */
    private String icon;

    /**
     * 工号
     */
    private String empNo;

    /**
     * 昵称
     */
    private String nickName;

    /**
     * 备注信息
     */
    private String note;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 最后登录时间
     */
    private Date loginTime;

    /**
     * 帐号启用状态：0->禁用；1->启用
     */
    private Integer status;
}
