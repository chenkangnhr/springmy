package com.msl.my.task.manage.business.dto.params;

import lombok.Data;

import java.io.Serializable;

/**
 * 修改密码参数
 * <p>
 * Description:
 * </p>
 *
 * @author King Chen
 */
@Data
public class PasswordParam implements Serializable {

    private static final long serialVersionUID = -7747731603429104145L;
    private String email;
    private String oldPassword;
    private String newPassword;

}
