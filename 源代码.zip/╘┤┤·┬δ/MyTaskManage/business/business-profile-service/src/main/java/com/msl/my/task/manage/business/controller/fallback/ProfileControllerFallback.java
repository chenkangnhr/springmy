package com.msl.my.task.manage.business.controller.fallback;


import com.msl.my.task.manage.commons.dto.ResponseResult;
import com.msl.my.task.manage.business.dto.AdminUserDTO;
import com.msl.my.task.manage.business.feign.fallback.ProfileFeignFallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 用户管理服务熔断器
 * <p>
 * Description:
 * </p>
 *
 * @author King Chen
 */
public class ProfileControllerFallback {

    private static final Logger logger = LoggerFactory.getLogger(ProfileControllerFallback.class);

    /**
     * 熔断方法
     *
     * @param email {@code String} 用户名
     * @return {@link ResponseResult< AdminUserDTO >}
     */
    public static ResponseResult<AdminUserDTO> infoFallback(String email, Throwable ex) {
        logger.warn("Invoke infoFallback: " + ex.getClass().getTypeName());
        ex.printStackTrace();
        return new ResponseResult<AdminUserDTO>(ResponseResult.CodeStatus.BREAKING, ProfileFeignFallback.BREAKING_MESSAGE);
    }

}
