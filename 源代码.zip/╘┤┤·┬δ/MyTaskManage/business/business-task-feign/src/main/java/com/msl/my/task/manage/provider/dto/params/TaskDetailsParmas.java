package com.msl.my.task.manage.provider.dto.params;

public class TaskDetailsParmas {
}
