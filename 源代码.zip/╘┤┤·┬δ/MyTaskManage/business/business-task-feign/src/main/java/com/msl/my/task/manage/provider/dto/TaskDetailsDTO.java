package com.msl.my.task.manage.provider.dto;

import lombok.Data;

import java.util.Date;
@Data
public class TaskDetailsDTO {
    /**
     * 任务编号
     */
    private String taskNo;

    /**
     * 任务所有者
     */
    private String taskOwner;

    /**
     * 任务类型，ELog,Esearch,Project,Training
     */
    private String taskType;

    /**
     * 任务描述
     */
    private String taskDesc;

    /**
     * 任务状态,1:计划中，2：Ur阶段，3：coding；4：sit；5：UAT；6：Done；9：进行中
     */
    private String taskStat;

    /**
     * 集成测试日期
     */
    private Date sitDate;

    /**
     * 用户测试日期
     */
    private Date uatDate;

    /**
     * 发布日期
     */
    private Date releaseDate;

    /**
     * 计划工时
     */
    private Long planManDays;

    /**
     * 实际工时
     */
    private Long actualDays;

    /**
     * 任务处理年月
     */
    private String taskMonth;

    /**
     * 创建时间
     */
    private Date createDay;

    /**
     * 修改时间
     */
    private Date modifyDay;
}
