package com.msl.my.task.manage.provider.feign.fallback;

public class TaskDetailFeignFallback {
}
