package com.msl.my.task.manage.provider.feign;

import com.msl.my.task.manage.configuration.feign.configuration.FeignRequestConfiguration;
import com.msl.my.task.manage.provider.feign.fallback.TaskDetailFeignFallback;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * @author chenk
 */

@FeignClient(value = "business-task", path = "task", configuration = FeignRequestConfiguration.class, fallback = TaskDetailFeignFallback.class)
public interface TaskDetailsFeign {
    /**
     * 获取任务信息
     *
     * @param empNo {@code String} 工号
     * @return {@code String} JSON
     */
    @GetMapping(value = "info/{empNo}")
    String info(@PathVariable String empNo);
}
