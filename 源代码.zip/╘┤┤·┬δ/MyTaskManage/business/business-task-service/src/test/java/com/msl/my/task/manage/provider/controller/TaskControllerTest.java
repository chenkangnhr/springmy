package com.msl.my.task.manage.provider.controller;

import com.msl.my.task.manage.provider.api.TaskDetailsService;
import com.msl.my.task.manage.provider.domain.TaskDetails;
import org.apache.dubbo.config.annotation.Reference;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;


@RunWith(SpringRunner.class)
@SpringBootTest
public class TaskControllerTest {
    @Reference(version = "1.0.0")
    private TaskDetailsService taskDetailsService;
    @Test
    public void info() {
        System.out.println(taskDetailsService.get("383604"));
    }
}