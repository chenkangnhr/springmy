package com.msl.my.task.manage.provider.controller;

import com.msl.my.task.manage.commons.dto.ResponseResult;
import com.msl.my.task.manage.provider.api.TaskDetailsService;
import com.msl.my.task.manage.provider.domain.TaskDetails;
import com.msl.my.task.manage.provider.dto.TaskDetailsDTO;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author chenk
 */
@RestController
@RequestMapping(value = "task")
public class TaskController {
    @Reference(version = "1.0.0")
    private TaskDetailsService taskDetailsService;

    @GetMapping(value = "info/{empNO}")
    public ResponseResult<TaskDetailsDTO> info(@PathVariable String empNO) {
        TaskDetails taskDetails = taskDetailsService.get(empNO);
        TaskDetailsDTO dto = new TaskDetailsDTO();
        BeanUtils.copyProperties(taskDetails, dto);
        return new ResponseResult<TaskDetailsDTO>(ResponseResult.CodeStatus.OK, "获取任务信息", dto);
    }

}
