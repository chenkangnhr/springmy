package com.msl.my.task.manage.provider;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @author chenk
 */
@SpringBootApplication
@EnableDiscoveryClient
public class BusinessTaskApplication {
    public static void main(String[] args) {
        SpringApplication.run(BusinessTaskApplication.class, args);
    }
}
