import request from '@/utils/request'

/**
 * 获取成员信息
 *
 */
export function getInfo() {
  return request({
    url: '/member/info/',
    method: 'get'
  })
}
/**
 * 更新成员信息
 * @param empNo 界面数据
 */
export function update(email) {
  return request({
    url: '/member/update' + email,
    method: 'post'
  })
}

/**
 * 添加成员信息
 * @param data 界面数据
 */
export function add(data) {
  return request({
    url: '/member/add',
    method: 'post',
    data
  })
}
