import request from '@/utils/request'

/**
 * 获取任务信息
 * @param empNO 工号
 */
export function getInfo(empNO) {
  return request({
    url: '/task/info/' + empNO,
    method: 'get'
  })
}
/**
 * 更新任务信息
 * @param data 界面数据
 */
export function update(data) {
  return request({
    url: '/task/update',
    method: 'post',
    data
  })
}

/**
 * 添加任务信息
 * @param data 界面数据
 */
export function add(data) {
  return request({
    url: '/task/add',
    method: 'post',
    data
  })
}
