import request from '@/utils/request'
/**
 * 获取个人信息
 * @param email 邮箱
 */
export function info(email) {
  return request({
    url: '/profile/info/'+ email,
    method: 'get'
  })
}


/**
 * 更新个人信息
 * @param data 界面数据
 */
export function update(data) {
  return request({
    url: '/profile/update/',
    method: 'post',
    data
  })
}
