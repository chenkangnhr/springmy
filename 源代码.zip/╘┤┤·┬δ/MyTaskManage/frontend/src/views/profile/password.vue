<template>

</template>

<script>
    export default {
        name: "ProfilePassword"
    }
</script>

<style scoped>

</style>
