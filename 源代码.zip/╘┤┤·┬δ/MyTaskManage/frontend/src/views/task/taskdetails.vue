<template>
  <div class="app-container">
    <el-table :data="taskList" style="width: 100%" max-height="500" border>
      <el-table-column prop="taskNo" label="任务编号" width="100">
      </el-table-column>
      <el-table-column prop="taskOwner" label="任务所属" width="80">
      </el-table-column>
      <el-table-column prop="taskType" label="任务类型" width="80">
      </el-table-column>
      <el-table-column prop="taskDesc" label="任务描述" width="120">
      </el-table-column>
      <el-table-column prop="taskStat" label="状态" width="50">
      </el-table-column>
      <el-table-column prop="sitDate" label="SIT时间" width="120">
      </el-table-column>
      <el-table-column prop="uatDate" label="UAT时间" width="120">
      </el-table-column>
      <el-table-column prop="releaseDate" label="发布时间" width="120">
      </el-table-column>
      <el-table-column prop="planManDays" label="预估工时" width="80">
      </el-table-column>

      <el-table-column prop="actualDays" label="实际工时" width="80">
      </el-table-column>
      <el-table-column prop="taskMonth" label="任务年月" width="80">
      </el-table-column>
      <el-table-column prop="createDay" label="创建时间" width="100">
      </el-table-column>
      <el-table-column prop="modifyDay" label="修改时间" width="100">
      </el-table-column>

        <el-table-column label="操作" width="120">
          <template slot-scope="scope">
            <el-button @click.native.prevent="deleteRow(scope.$index, taskList)" type="text" size="small">
              移除
            </el-button>
          </template>
        </el-table-column>

    </el-table>
  </div>
</template>

<script>
  import { info, update } from '@/api/taskdetails'
  export default {
    name: "TaskDetail",
    methods: {
      deleteRow(index, rows) {
        rows.splice(index, 1);
      }
    },
    data() {
      return {
        taskList: [{
          taskNo: '20193624',
          taskOwner: '383604',
          taskType: 'ELOG',
          taskDesc: '高净值需求',
          taskStat: '1',
          sitDate: '2020-03-24',
          uatDate: '2020-03-28',
          releaseDate: '2020-04-01',
          planManDays: 8,
          actualDays: 2,
          taskMonth: '202003',
          createDay: '2020-03-22',
          modifyDay: '2020-03-22'
        },
          {
            taskNo: '20193625',
            taskOwner: '383604',
            taskType: 'ELOG',
            taskDesc: '短信需求',
            taskStat: '1',
            sitDate: '2020-03-24',
            uatDate: '2020-03-28',
            releaseDate: '2020-04-01',
            planManDays: 5,
            actualDays: 3,
            taskMonth: '202003',
            createDay: '2020-03-22',
            modifyDay: '2020-03-22'
          },
          {
            taskNo: '20193626',
            taskOwner: '383604',
            taskType: 'ELOG',
            taskDesc: '核保需求',
            taskStat: '1',
            sitDate: '2020-03-24',
            uatDate: '2020-03-28',
            releaseDate: '2020-04-01',
            planManDays: 8,
            actualDays: 6,
            taskMonth: '202003',
            createDay: '2020-03-22',
            modifyDay: '2020-03-22'
          },
          ]
      }
    }
  }
</script>

<style scoped>

</style>

