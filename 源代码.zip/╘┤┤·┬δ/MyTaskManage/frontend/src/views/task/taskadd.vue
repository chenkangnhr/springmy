<template>
  <div class="app-container">
    <el-form ref="task" :model="task" label-width="120px">
      <el-form-item label="Log编号">
        <el-input v-model="task.taskNo" />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="onSubmit">Create</el-button>
        <el-button @click="onCancel">Cancel</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
    export default {
      name: "taskAdd",
      data() {
        return {
          task: {
            taskNo: '20193624',
            taskOwner: '383604',
            taskType: 'ELOG',
            taskDesc: '高净值需求',
            taskStat: '1',
            sitDate: '2020-03-24',
            uatDate: '2020-03-28',
            releaseDate: '2020-04-01',
            planManDays: 8,
            actualDays: 2,
            taskMonth: '202003',
            createDay: '2020-03-22',
            modifyDay: '2020-03-22'
          }
        }
      },
      methods: {
        onSubmit() {
          this.$message('submit!')
        },
        onCancel() {
          this.$message({
            message: 'cancel!',
            type: 'warning'
          })
        }
      }
    }
</script>

<style scoped>

</style>
